# Changelog

## v0.1.0 (Unreleased)
* Fixed search parameter for `include`, added search parameter `revinclude` [#121](https://github.com/FHIR/fhir.js/issues/121) [PR#99](https://github.com/FHIR/fhir.js/pull/99)
* native.js credentials [#122](https://github.com/FHIR/fhir.js/issues/122)
* Missing defer property in Adapter object of native.js [#119](https://github.com/FHIR/fhir.js/issues/119)
